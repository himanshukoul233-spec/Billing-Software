require("dotenv").config();
const fs = require("fs");
const { Pool } = require("pg");
(async () => {
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  try {
    const sql = fs.readFileSync("./db/schema.sql", "utf8");
    await pool.query(sql);
    console.log("Database schema created.");
  } catch (e) { console.error(e); process.exitCode = 1; }
  finally { await pool.end(); }
})();
