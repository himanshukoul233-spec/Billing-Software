require("dotenv").config();
const express = require("express");
const session = require("express-session");
const PgSession = require("connect-pg-simple")(session);
const { Pool } = require("pg");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");

const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const isProd = process.env.NODE_ENV === "production";

if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  throw new Error("SESSION_SECRET must be set to a random value of at least 32 characters.");
}
if (isProd && process.env.COOKIE_SECURE !== "true") {
  throw new Error("Set COOKIE_SECURE=true in production and serve the app over HTTPS.");
}
app.set("trust proxy", isProd ? 1 : false);
app.use(helmet());
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));
app.use(session({
  store: new PgSession({ pool, createTableIfMissing: true }),
  name: "billing.sid",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: isProd,
    sameSite: "lax",
    maxAge: 8 * 60 * 60 * 1000
  }
}));
app.use(express.static(path.join(__dirname, "public")));

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false });
const registrationLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 5, standardHeaders: true, legacyHeaders: false });

function requireAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "Please log in." });
  next();
}
function requireRole(role) {
  return (req, res, next) => {
    if (!req.session.user || req.session.user.role !== role) {
      return res.status(403).json({ error: "Access denied." });
    }
    next();
  };
}
function cleanUser(row) {
  return { id: row.id, name: row.name, username: row.username, role: row.role, shopId: row.shop_id };
}

app.get("/api/health", async (_req, res) => {
  try { await pool.query("SELECT 1"); res.json({ ok: true, service: "Billing Software API" }); }
  catch { res.status(503).json({ ok: false }); }
});

app.post("/api/register-shop", registrationLimiter, async (req, res) => {
  const { shopName, email, phone, ownerName, username, password } = req.body || {};
  if (![shopName, email, ownerName, username, password].every(v => typeof v === "string" && v.trim())) {
    return res.status(400).json({ error: "Please complete all required fields." });
  }
  if (password.length < 12) return res.status(400).json({ error: "Use a password with at least 12 characters." });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || username.length > 100 || shopName.length > 150) {
    return res.status(400).json({ error: "Please check the entered details." });
  }
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const shop = await client.query(
      "INSERT INTO shops(shop_name,email,phone,status) VALUES($1,$2,$3,'pending') RETURNING id",
      [shopName.trim(), email.trim().toLowerCase(), (phone || "").trim()]
    );
    const hash = await bcrypt.hash(password, 12);
    await client.query(
      "INSERT INTO users(shop_id,name,username,password_hash,role) VALUES($1,$2,$3,$4,'shop_owner')",
      [shop.rows[0].id, ownerName.trim(), username.trim().toLowerCase(), hash]
    );
    await client.query("COMMIT");
    res.status(201).json({ message: "Registration submitted. Your account will be activated after admin approval." });
  } catch (e) {
    await client.query("ROLLBACK");
    if (e.code === "23505") return res.status(409).json({ error: "Email or username is already registered." });
    console.error(e);
    res.status(500).json({ error: "Registration could not be completed." });
  } finally { client.release(); }
});

app.post("/api/login", loginLimiter, async (req, res) => {
  const { username, password } = req.body || {};
  if (typeof username !== "string" || typeof password !== "string") return res.status(400).json({ error: "Enter username and password." });
  try {
    const result = await pool.query(
      `SELECT u.id,u.name,u.username,u.password_hash,u.role,u.shop_id,u.active,
              s.status AS shop_status,s.subscription_expires_at
       FROM users u LEFT JOIN shops s ON s.id=u.shop_id
       WHERE u.username=$1`,
      [username.trim().toLowerCase()]
    );
    const user = result.rows[0];
    const valid = user && await bcrypt.compare(password, user.password_hash);
    if (!valid || !user.active) return res.status(401).json({ error: "Invalid login details." });
    if (user.role === "shop_owner" &&
        (user.shop_status !== "active" || !user.subscription_expires_at || new Date(user.subscription_expires_at) < new Date())) {
      return res.status(403).json({ error: "Your shop account is not active. Please contact the software administrator." });
    }
    req.session.regenerate(err => {
      if (err) return res.status(500).json({ error: "Could not create a secure session." });
      req.session.user = cleanUser(user);
      res.json({ message: "Login successful.", user: req.session.user });
    });
  } catch (e) { console.error(e); res.status(500).json({ error: "Login could not be completed." }); }
});

app.get("/api/me", requireAuth, (req, res) => res.json({ user: req.session.user }));
app.post("/api/logout", requireAuth, (req, res) => req.session.destroy(() => {
  res.clearCookie("billing.sid", { httpOnly: true, sameSite: "lax", secure: isProd });
  res.json({ message: "Logged out." });
}));

// Admin-only overview. Never accept a shop_id from the browser for this view.
app.get("/api/admin/shops", requireRole("super_admin"), async (_req, res) => {
  try {
    const r = await pool.query(
      `SELECT s.id,s.shop_name,s.email,s.phone,s.status,s.subscription_plan,
              s.subscription_starts_at,s.subscription_expires_at,s.created_at
       FROM shops s ORDER BY s.created_at DESC LIMIT 500`
    );
    res.json({ shops: r.rows });
  } catch (e) { console.error(e); res.status(500).json({ error: "Could not load shops." }); }
});

// Admin approves a pending shop and sets subscription dates.
app.post("/api/admin/shops/:id/activate", requireRole("super_admin"), async (req, res) => {
  const shopId = Number(req.params.id);
  const { plan } = req.body || {};
  const durations = { monthly: 1, quarterly: 3, yearly: 12 };
  if (!Number.isSafeInteger(shopId) || shopId < 1 || !durations[plan]) return res.status(400).json({ error: "Invalid shop or plan." });
  try {
    const r = await pool.query(
      `UPDATE shops SET status='active',subscription_plan=$2,
       subscription_starts_at=NOW(),
       subscription_expires_at=NOW() + ($3::text || ' months')::interval
       WHERE id=$1 RETURNING id,status,subscription_plan,subscription_expires_at`,
      [shopId, plan, durations[plan]]
    );
    if (!r.rowCount) return res.status(404).json({ error: "Shop not found." });
    res.json({ shop: r.rows[0] });
  } catch (e) { console.error(e); res.status(500).json({ error: "Activation failed." }); }
});

// Shop owner can only see their own shop record; shop ID is taken from session.
app.get("/api/shop/me", requireRole("shop_owner"), async (req, res) => {
  try {
    const r = await pool.query(
      "SELECT id,shop_name,email,phone,status,subscription_plan,subscription_expires_at FROM shops WHERE id=$1",
      [req.session.user.shopId]
    );
    if (!r.rowCount) return res.status(404).json({ error: "Shop not found." });
    res.json({ shop: r.rows[0] });
  } catch (e) { console.error(e); res.status(500).json({ error: "Could not load shop." }); }
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Unexpected server error." });
});
const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Billing Software API running on port ${port}`));
