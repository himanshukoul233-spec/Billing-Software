# Billing Software — Authentication Starter

This is development milestone 0.2 for the commercial Billing Software:
- Shop registration (pending approval)
- Separate `super_admin` and `shop_owner` roles
- Password hashing with bcrypt
- PostgreSQL-backed sessions and login rate limiting
- Admin shop list and manual shop activation endpoints
- Shop-owner endpoint that derives the shop ID from the authenticated session
- Responsive English sign-in and shop-registration screens
- Super Admin dashboard with shop counts, registration list and subscription activation controls
- Shop Owner dashboard with shop profile and subscription status

## Requirements
- Node.js 20+
- PostgreSQL 14+
- HTTPS reverse proxy for production

## Run locally
1. Create a PostgreSQL database named `billing_software`.
2. Copy `.env.example` to `.env` and set `DATABASE_URL` and a random `SESSION_SECRET` (at least 32 characters).
3. Install dependencies: `npm install`
4. Create tables: `npm run db:init`
5. Create the first Super Admin using the one-time bootstrap instructions below.
6. Start: `npm start`
7. Open `http://localhost:3000`

## Create the first Super Admin (one-time)
Do not expose a public Super Admin registration form. After the database schema is initialized, run this command from the project folder, replacing values:

```bash
node -e "require('dotenv').config(); const {Pool}=require('pg'); const b=require('bcryptjs'); (async()=>{const p=new Pool({connectionString:process.env.DATABASE_URL}); const h=await b.hash('REPLACE_WITH_A_LONG_UNIQUE_PASSWORD',12); await p.query(\"INSERT INTO users(shop_id,name,username,password_hash,role) VALUES(NULL,$1,$2,$3,'super_admin')\",['Software Administrator','admin',h]); await p.end();})().catch(e=>{console.error(e);process.exit(1)})"
```

Change `admin` and the password before running it. Store the credentials securely.

## Dashboard behavior
- The Super Admin dashboard loads data from the protected `/api/admin/shops` endpoint.
- The Shop Owner dashboard loads only the signed-in owner's shop via `/api/shop/me`; the browser cannot choose a shop ID.
- Pending shops can be activated on a monthly, quarterly or yearly plan after the administrator separately verifies payment. The current activation endpoint does not itself verify a payment receipt.
- This milestone does not yet include operational billing, inventory or sales data.

## Admin endpoints
- `GET /api/admin/shops` — list shops (Super Admin only)
- `POST /api/admin/shops/:id/activate` with JSON `{"plan":"monthly"}`, `{"plan":"quarterly"}`, or `{"plan":"yearly"}` — activate subscription (Super Admin only)

## Important production gaps — not ready to sell yet
This is a starter, not a finished commercial product. Before public launch, add and test:
- CSRF protection for cookie-authenticated state-changing routes
- Email/phone verification, password reset, MFA for Super Admin, audit logs
- Payment-submission records, receipt/proof handling, and approval workflow linked to actual verified payments
- Database row-level security or rigorously tested tenant-scoped data access for every business table
- Product, invoice, GST, inventory, purchase, ledger and reporting modules
- PDF generation, WhatsApp sharing integration, camera barcode scanning and printer compatibility
- Automated tests, backups/restore drills, monitoring, logging, privacy policy and terms
- Production deployment, HTTPS, secret management, vulnerability review and load testing

Never use the development configuration with real customer data. Keep `.env` private and never commit it.
